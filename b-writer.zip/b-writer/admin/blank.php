<?php 
$page = "Blank Page";
include "templates/header.php"; ?>



</div>
<!-- End of Main Content -->

<?php include "templates/footer.html"; ?>