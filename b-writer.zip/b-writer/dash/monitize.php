<?php 
$page = "Monitize";
$id = "monitize";
include "templates/header.php"; ?>
<script>
$("#<?php echo $id ?>").attr("class", "nav-item active");
</script>
<br><br><br><br><br><br><br><br>

<center>
    <h3>COMING SOON!</h3>
</center>
</div>
<!-- End of Main Content -->
<br><br><br><br><br><br><br><br>
<?php include "templates/footer.html"; ?>